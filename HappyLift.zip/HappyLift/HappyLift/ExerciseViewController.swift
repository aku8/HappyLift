//
//  ExerciseViewController.swift
//  HappyLift
//
//  Created by Anina Ku on 11/24/19.
//  Copyright © 2019 Anina Ku. All rights reserved.
//

import UIKit

//protocol code from https://fluffy.es/3-ways-to-pass-data-between-view-controllers/#delegate
//sets up relationship for viewController to exercute copyArray function with
//data from this view controller
protocol ExerciseViewControllerDelegate : NSObjectProtocol {
    func copyArray(data: Array<Any>)
}

class ExerciseViewController: UIViewController {
    
    var newMaxWeight: Int!
    var newMaxReps: Int!
    
    var inputWeight: String!
    var inputReps: String!
    
    var url: String!
    var id: Int!
    var name: String!
    var exerciseDescription: String!
    var maxArray: [ExerciseMax] = []
    weak var delegate : ExerciseViewControllerDelegate?
    
    @IBOutlet var maxWeight: UITextField!
    @IBOutlet var maxReps: UITextField!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var imageView1: UIImageView!
    @IBOutlet var imageView2: UIImageView!
    @IBOutlet var currentMaxWeight: UILabel!
    @IBOutlet var currentMaxReps: UILabel!
    
    //saves user input when "Save" button pressed
    @IBAction func saveMaxValue() {
        inputWeight = maxWeight.text
        inputReps = maxReps.text
        newMaxWeight = Int(inputWeight!)
        newMaxReps = Int(inputReps!)
        
        //Updates "Current Max" info on screen
        currentMaxWeight.text = "\(newMaxWeight!)"
        currentMaxReps.text = "\(newMaxReps!)"
        
        //adds the values to the right exercise's entry in maxArray
        for index in 0..<maxArray.count {
            if maxArray[index].exercise == self.id {
                maxArray[index].maxWeight = newMaxWeight
                maxArray[index].maxReps = newMaxReps
            }
        }
        
        //Relationship to send data back to ExerciseListViewController
        if let delegate = delegate{
            delegate.copyArray(data: maxArray)
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        nameLabel.text = ""
        
        loadExercise()
        loadPhotos()
        loadInitialMax()
    }
    
    //loads current max info from maxArray
    func loadInitialMax() {
        for entry in self.maxArray {
            if entry.exercise == self.id {
                currentMaxWeight.text = "\(entry.maxWeight)"
                currentMaxReps.text = "\(entry.maxReps)"
            }
        }
    }
    
    //Load the exercise name - go through API pages until right exercise found
    func loadExercise() {
        for page in 1...31 {
            
            guard let url = URL(string: "https://wger.de/api/v2/exercise/?page=\(page)") else {
                return
            }
            
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                guard let data = data else {
                    return
                }
                
                do {
                    let result = try JSONDecoder().decode(ExerciseListResults.self, from: data)
                    DispatchQueue.main.async {
                        
                        for entry in result.results {
                            if entry.id == self.id {
                                
                                self.name = entry.name
                                self.nameLabel.text = self.name
                            }
                        }
                    }
                }
                catch let error {
                    print(error)
                }
            }.resume()
        }
    }
    
    //Photos API is separate, so a this function searches for the right photos (by id)
    func loadPhotos() {
        for page in 1...11 {
            guard let url2 = URL(string: "https://wger.de/api/v2/exerciseimage/?page=\(page)") else {
                return
            }
            
            URLSession.shared.dataTask(with: url2) { (data2, response2, error2) in
                guard let data2 = data2 else {
                    return
                }
                
                do {
                    let result = try JSONDecoder().decode(ImageListResults.self, from: data2)
                    DispatchQueue.main.async {
                        
                        //used to differentiate between photo 1 and photo 2
                        var count = 0
                        
                        for entry in result.results {
                            if entry.exercise == self.id {
                                //adding image: taken from Pokedex
                                if count == 0 {
                                    let imageUrlString = entry.image
                                    let imageUrl:URL = URL(string: imageUrlString)!
                                    
                                    
                                    let imageData:NSData = NSData(contentsOf: imageUrl)!
                                    let imageView1 = UIImageView(frame: CGRect(x:50, y:180, width:150, height:150))
                                    
                                    let image = UIImage(data: imageData as Data)
                                    imageView1.image = image
                                    imageView1.contentMode = UIView.ContentMode.scaleAspectFit
                                    self.view.addSubview(imageView1)
                                    count += 1
                                }
                                else {
                                    let imageUrlString = entry.image
                                    let imageUrl:URL = URL(string: imageUrlString)!
                                    
                                    
                                    let imageData:NSData = NSData(contentsOf: imageUrl)!
                                    let imageView2 = UIImageView(frame: CGRect(x:210, y:180, width:150, height:150))
                                    
                                    let image = UIImage(data: imageData as Data)
                                    imageView2.image = image
                                    imageView2.contentMode = UIView.ContentMode.scaleAspectFit
                                    self.view.addSubview(imageView2)
                                }
                            }
                        }
                    }
                }
                catch let error {
                    print(error)
                }
            }.resume()
        }
    }
}
