//
//  ViewController.swift
//  HappyLift
//
//  Created by Anina Ku on 11/21/19.
//  Copyright © 2019 Anina Ku. All rights reserved.
//


import UIKit

class ExerciseListViewController: UITableViewController, UISearchBarDelegate, ExerciseViewControllerDelegate {
    
    @IBOutlet var searchBar: UISearchBar!
    
    var exercises: [ExerciseListResult] = []
    var filteredExercises: [ExerciseListResult] = []
    var exercisesMaxData: [ExerciseMax] = []
    var viewLoadCount = 0
    
    
    //the database has a lot of junk entries created by other users. I picked out entries that were well-written and had good images, and recorded their IDs here.
    var desiredExercises: [Int] = [88, 129, 74, 81, 82, 86, 195, 113, 191, 116, 154, 117, 177, 310, 97, 98, 122, 109, 181, 128, 143, 148, 123]
    
    @IBAction func deleteAllData() {
        
        //resets the array to be passed to view controller
        for index in 0..<exercisesMaxData.count {
            exercisesMaxData[index].maxWeight = 0
            exercisesMaxData[index].maxReps = 0
        }
        
        //resets user defaults
        resetDefaults()
        
    }
    
    //from Pokedex - useful to capitalize entries
    func capitalize(text: String) -> String {
        return text.prefix(1).uppercased() + text.dropFirst()
    }
    
    //for testing purposes - from https://stackoverflow.com/questions/43402032/how-to-remove-all-userdefaults-data-swift?noredirect=1&lq=1
    //will reset User Defaults
    func resetDefaults() {
        let defaults = UserDefaults.standard
        let dictionary = defaults.dictionaryRepresentation()
        dictionary.keys.forEach { key in
            defaults.removeObject(forKey: key)
        }
    }
    
    //Used to receive information back from the Exercise View Controller
    //Updates the array of max data
    func copyArray(data: Array<Any>) {
        exercisesMaxData = data as! [ExerciseMax]
        
        var justWeights: [Int] = []
        var justReps: [Int] = []
        
        for entry in exercisesMaxData {
            let maxWeight = entry.maxWeight
            justWeights.append(maxWeight)
            
            let maxReps = entry.maxReps
            justReps.append(maxReps)
        }
        
        //Then updates User Defaults for the max data arrays
        let defaults = UserDefaults.standard
        defaults.set(justWeights, forKey: "SavedMaxWeightArray")
        defaults.set(justReps, forKey: "SavedMaxRepsArray")
        
        let maxWeights = defaults.array(forKey: "SavedMaxWeightArray")as? [Int] ?? [Int]()
        for index in 0..<self.exercisesMaxData.count {
            self.exercisesMaxData[index].maxWeight = maxWeights[index]
        }
        
        let maxReps = defaults.array(forKey: "SavedMaxRepsArray")as? [Int] ?? [Int]()
        for index in 0..<self.exercisesMaxData.count {
            self.exercisesMaxData[index].maxReps = maxReps[index]
        }
    }
    
    //following code is from https://guides.codepath.com/ios/Search-Bar-Guide
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredExercises = searchText.isEmpty ? exercises: exercises.filter { (item: ExerciseListResult) -> Bool in
            return item.name.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
        }
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.delegate = self
        
        //A counter used to associate exercises to the correct max data value
        var i = 0
        
        //The API requires you to go through 31 different pages to get all of the exercises
        for page in 1...31 {
            
            guard let url = URL(string: "https://wger.de/api/v2/exercise/?page=\(page)") else {
                return
            }
            
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                guard let data = data else {
                    return
                }
                
                do {
                    let entries = try JSONDecoder().decode(ExerciseListResults.self, from: data)
                    
                    for result in entries.results {
                        //checking if exercise ID from API is in my list of desired exercises
                        if self.desiredExercises.contains(result.id) {
                            self.exercises.append(result)
                            self.filteredExercises.append(result)
                            
                            let defaults = UserDefaults.standard
                            
                            //if userDefaults has been updated (app has been used before)
                            if defaults.array(forKey: "SavedMaxWeightArray") != nil {
                                
                                //get array of just the max numbers
                                let maxWeights = defaults.array(forKey: "SavedMaxWeightArray")
                                let maxRep = defaults.array(forKey: "SavedMaxRepsArray")
                                
                                //create an updated entry, exercise ID + max data, and add to exercisesMaxData
                                let currentData = ExerciseMax(exercise: result.id, maxWeight: maxWeights![i] as! Int, maxReps: maxRep![i] as! Int)
                                i += 1
                                self.exercisesMaxData.append(currentData)
                                
                                
                            }
                                //if userDefaults has not been updated - app opened for the first time ever
                            else {
                                //fill in exerciseMaxData with all exercises, and all 0's for weight
                                let currentData = ExerciseMax(exercise: result.id, maxWeight: 0, maxReps: 0)
                                self.exercisesMaxData.append(currentData)
                            }
                        }
                    }
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                }
                catch let error {
                    print(error)
                }
            }.resume()
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredExercises.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExerciseCell", for: indexPath)
        cell.textLabel?.text = capitalize(text: filteredExercises[indexPath.row].name)
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowExerciseSegue",
            let destination = segue.destination as? ExerciseViewController,
            let index = tableView.indexPathForSelectedRow?.row {
            destination.id = filteredExercises[index].id
            
            //Pass on exerciseMaxData to ExerciseViewController
            destination.maxArray = exercisesMaxData
            
            //Set up relationship to receive data from ExerciseViewController
            let displayVC = segue.destination as! ExerciseViewController
            displayVC.delegate = self
        }
    }
}





