//
//  Exercises.swift
//  HappyLift
//
//  Created by Anina Ku on 11/21/19.
//  Copyright © 2019 Anina Ku. All rights reserved.
//

import Foundation

struct ExerciseListResults: Codable {
    let results: [ExerciseListResult]
}

struct ExerciseListResult: Codable {
    let name: String
    let id: Int
    let description: String
}

struct ImageListResults: Codable {
    let results: [ImageListResult]
}

struct ImageListResult: Codable {
    let image: String
    let exercise: Int
}

struct ExerciseMax: Codable {
    var exercise: Int
    var maxWeight: Int
    var maxReps: Int
}


